Thanks for downloading my ebook converter.

This is a totally open project writen in autoit script.
Please feel free to modify and re-release this script as you choose.
The converters were not written by me and are the property of their respective owners.


Currently there is no main interface for this application. Just point it to a file and let it do the work. One file at a time Please.
Converts non-drm lit pdf and html files to mobi format for the kindle and other readers that support this format.
Pdf images are not implimented at this time.

Contact
samurai@deadmessengers.net
forum.deadmessengers.net